#!/bin/sh

echo "postflight: started with file $FILELIST on path $ROOTPATH and bundlepath $BUNDLEPATH"
echo "current uid=${UID}, euid=${EUID}, user=${USER}"

# stop hamachid if preflight.sh was not successfull
launchctl unload -w /Library/LaunchDaemons/com.logmein.hamachi.plist
launchctl unload -w com.logmein.hamachi
killall LogMeIn\ Hamachi

/Applications/LogMeIn\ Hamachi/LogMeIn\ Hamachi.app/Contents/Resources/hamachidaemonctl stop

#prevent leaking drivers
kextunload -v 6 /Library/Extensions/ham.kext
kextunload -v 6 /Library/Extensions/hamns.kext
kextunload -v 6 /System/Library/Extensions/ham.kext
kextunload -v 6 /System/Library/Extensions/hamns.kext
kextunload -v 6 -b com.logmein.hamachi
sleep 1

[ -d /etc/resolver ] || mkdir -p -m 755 /etc/resolver

# create link
/bin/ln -sf "/Library/Application Support/LogMeIn Hamachi/bin/hamachid" /usr/bin/hamachi
mkdir /usr/local/bin
/bin/ln -sf "/Library/Application Support/LogMeIn Hamachi/bin/hamachid" /usr/local/bin/hamachi


# need to remove write from group
/bin/chmod go-w "/Library/LaunchDaemons/com.logmein.hamachi.plist"
/bin/chmod go-w "/Library/LaunchAgents/com.logmein.hamachimb.plist"
/bin/chmod -R go-w "/Library/Extensions/ham.kext"
/bin/chmod -R go-w "/Library/Extensions/hamns.kext"
chown -R root:wheel "/Library/Extensions/ham.kext"
chown -R root:wheel "/Library/Extensions/hamns.kext"

rm -R "/System/Library/Extensions/hamns.kext"
mv -f "/Library/Extensions/hamns.kext" "/System/Library/Extensions/"
rm -R "/Library/Extensions/hamns.kext"

chown root:wheel "/Library/LaunchDaemons/com.logmein.hamachi.plist"
chown root:wheel "/Library/LaunchDaemons/com.logmein.hamachimb.plist"

INSTALL_LINK="/tmp/hamachi_deploy_id"
ENGINE_CFG="/Library/Application Support/LogMeIn Hamachi/config/h2-engine.cfg"

mkdir -p "/Library/Application Support/LogMeIn Hamachi/config/"

/bin/cat  "$INSTALL_LINK" >> "$ENGINE_CFG"
rm "$INSTALL_LINK"
rm "$INSTALL_LINK.bak"

chmod 777 "/Library/Application Support/LogMeIn Hamachi/run"

pv=`/usr/bin/sw_vers -productVersion`

# cleaning drivers by OS version
case $pv in
	10.4.*)
		rm -R "/Library/Extensions/ham.kext"
		;;
	10.5.*)
		rm -R "/Library/Extensions/ham.kext"
		;;
	10.6.*)
		rm -R "/Library/Extensions/ham.kext"
		;;
	10.7.*)
		rm -R "/Library/Extensions/ham.kext"
		;;
	10.8.*)
# need both version, see http://www.tonymacx86.com/attachment.php?attachmentid=70514
		;;
	*)
		rm -R "/System/Library/Extensions/hamns.kext"
		;;
esac

echo Starting Engine...
#start daemon
sleep 2
sudo -u root launchctl load -w /Library/LaunchDaemons/com.logmein.hamachi.plist
sudo launchctl load -w /Library/LaunchDaemons/com.logmein.hamachi.plist
/Applications/LogMeIn\ Hamachi/LogMeIn\ Hamachi.app/Contents/Resources/hamachidaemonctl start

sleep 2
echo Engine started

echo Starting MenuBars...
case $pv in
	10.4.*)
		launchctl load -w /Library/LaunchAgents/com.logmein.hamachimb.plist
		;;
	*)
		SaveIFS=$IFS
		IFS="\n"
		alluisessions=`ps axo "user pid command" | grep -v grep | grep loginwindow | tr -s ' ' | cut -f 1-2 -d' '`
		alluisessions=`echo $alluisessions | tr "\n" "|"`
		IFS="|"
		for uisession in $alluisessions
		do
			uiusername=`echo $uisession | cut -f 1 -d' '`
			uipid=`echo $uisession | cut -f 2 -d' '`
			if [ x"root" != x"$uiusername" ]; then
				echo "uipid: "$uipid" -  uiusername: "$uiusername
				launchctl bsexec $uipid sudo -u $uiusername launchctl load -w /Library/LaunchAgents/com.logmein.hamachimb.plist
				sudo -u $uiusername launchctl load -w /Library/LaunchAgents/com.logmein.hamachimb.plist
			fi
		done
		IFS=$SaveIFS
		;;
 esac
 echo MenuBars started

exit  0
