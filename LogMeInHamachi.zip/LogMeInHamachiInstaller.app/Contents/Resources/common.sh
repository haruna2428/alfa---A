#!/bin/bash -p

LAST_BUNDLED_HOST_BUILD_VERSION=5259
LAST_BUNDLED_CLIENT_BUILD_VERSION=5059
STANDALONE_CLIENT_BUILD_VERSIONS="4811 4822 4907 5061"

CONFIG_FILE_PATH="/Library/Application Support/LogMeIn/config.xml"


function getBundleBuildVersion()
{
    if [ ! -d "$1" ] ; then
        return 1
    fi

    # mdls result is in format: 'kMDItemVersion = "4.1.5015"'
    local VERSION=`mdls -name kMDItemVersion "$1" | sed -n -e 's/^kMDItemVersion.*".*\.\(.*\)"/\1/p'`
    # if ever mdls fails try with parsing the Info.plist file
    if [ "$VERSION" == "" ] ; then
        VERSION=`grep -A 1 -e "<key>CFBundleVersion</key>" "$1/Contents/Info.plist" | sed -n -e 's/.*<string>.*\.\(.*\)<\/string>.*/\1/p'`
    fi
    echo ${VERSION}
    return 0
}

function checkClientVersion()
{
    INSTALLED_BUNDLED_CLIENT=0

    INSTALLED_HOST_BUILD_VERSION=`getBundleBuildVersion "/Library/Application Support/LogMeIn/bin/LogMeIn.app/"`
    if [ "$INSTALLED_HOST_BUILD_VERSION" != "" ] ; then
        echo "Found installed host, build version: $INSTALLED_HOST_BUILD_VERSION"
        if [ 0$INSTALLED_HOST_BUILD_VERSION -le 0$LAST_BUNDLED_HOST_BUILD_VERSION ] ; then
            # older than or the same as the latest bundled host version
            INSTALLED_BUNDLED_CLIENT="1"
        fi
    else
        echo "Could not find installed host"
    fi

    INSTALLED_CLIENT_BUILD_VERSION=`getBundleBuildVersion "/Applications/LogMeIn Client.app"`
    if [ "$INSTALLED_CLIENT_BUILD_VERSION" != "" ] ; then
        echo "Found installed client, build version: $INSTALLED_CLIENT_BUILD_VERSION"
        if [ 0$INSTALLED_CLIENT_BUILD_VERSION -gt 0$LAST_BUNDLED_CLIENT_BUILD_VERSION ] ; then
            # newer than the latest bundled client version
            INSTALLED_BUNDLED_CLIENT="0"
        else
            # check for exact standalone client versions
            for VERSION in $STANDALONE_CLIENT_BUILD_VERSIONS ; do
                if [ "$INSTALLED_CLIENT_BUILD_VERSION" = "$VERSION" ] ; then
                    INSTALLED_BUNDLED_CLIENT="0"
                    break
                fi
            done
        fi
    else
        echo "Could not find installed client"
    fi

    echo "Bundled client: $INSTALLED_BUNDLED_CLIENT"
}


# functions for reading config file
function getConfigValue()
{
    local KEYPATH="/"
    for KEY in $(echo "$1" | tr "/" "\n") ; do
        KEYPATH="${KEYPATH}/key[@name=\"${KEY}\"]"
    done
    KEYPATH="${KEYPATH}/$3[@name=\"$2\"]/text()"

    local VALUE=$(echo "cat ${KEYPATH}" | xmllint --shell "${CONFIG_FILE_PATH}" | grep -v -e "^/ > ")
    : ${VALUE:=$4}

    echo ${VALUE}
}

function getConfigStringValue()
{
    getConfigValue "$1" "$2" "string" "$3"
}

function getConfigDWordValue()
{
    getConfigValue "$1" "$2" "dword" "$3"
}


# functions to install client
function installClient()
{
    local DMG_FILE="$1"
    local APP_BUNDLE="LogMeIn Client.app"
    local MOUNT_DIR="/var/tmp/LogMeInClientPackage_$$"
    local TARGET_DIR="/Applications"

    echo "Mount disk image ${DMG_FILE} at ${MOUNT_DIR}"
    DEV_NAME=$(hdiutil attach -nobrowse -mountpoint "${MOUNT_DIR}" "${DMG_FILE}" | tail -1 | awk '{print $1}')
    echo "Device name: ${DEV_NAME}"

    if [ "${DEV_NAME}" = "" ] ; then
        echo "Failed to mount disk image, cannot install client"
        return
    fi

    echo "Copy application bundle to ${TARGET_DIR}/${APP_BUNDLE}"
    rm -Rf "${TARGET_DIR}/${APP_BUNDLE}"
    cp -Rf "${MOUNT_DIR}/${APP_BUNDLE}" "${TARGET_DIR}/"

    # set owner to the installer user
    echo "Set owner to ${UID} on ${TARGET_DIR}/${APP_BUNDLE}"
    chown -R ${UID} "${TARGET_DIR}/${APP_BUNDLE}"

    echo "Unmounting disk image"
    hdiutil detach ${DEV_NAME}
}

function downloadAndInstallClient()
{
    local INSTALL_PACKAGE="/var/tmp/LogMeInClient_$$.dmg"

    rm -f "${INSTALL_PACKAGE}"

    echo "Download client installer to ${INSTALL_PACKAGE}"

    # must be run from bin directory so as to load config
    pushd "/Library/Application Support/LogMeIn/bin/"
    "LogMeIn.app/Contents/MacOS/LogMeIn" --download-client "${INSTALL_PACKAGE}" >/dev/null 2>&1
    local DOWNLOAD_RESULT=$?
    popd

    if [ "${DOWNLOAD_RESULT}" = "0" ] ; then
        echo "Install client"
        installClient "${INSTALL_PACKAGE}"
    else
        echo "Download failed, error: ${DOWNLOAD_RESULT}, cannot install client"
    fi

    # remove the file, when curl fails it can produce something, too
    rm -f "${INSTALL_PACKAGE}"
}

function checkInstallClientParam()
{
    PARAM_INSTALL_CLIENT=0
    while [ "$1" != "" ] ; do
        if [ "$1" = "--install-client" ] ; then
            PARAM_INSTALL_CLIENT=1
            break
        fi
        shift
    done
}

function installClientIfNeeded()
{
    echo "Install client: ${PARAM_INSTALL_CLIENT}"
    if [ "${PARAM_INSTALL_CLIENT}" != "1" ] ; then
        return
    fi

    # if client already exists (was not removed previously) don't touch it
    local CLIENT_BUILD_VERSION=`getBundleBuildVersion "/Applications/LogMeIn Client.app"`
    if [ "$CLIENT_BUILD_VERSION" != "" ] ; then
        echo "Client already installed"
        return
    fi

    downloadAndInstallClient
}

